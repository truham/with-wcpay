import { useState, useEffect, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Alert,
  RefreshControl,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { useTurnkey, ClientState } from "@turnkey/react-native-wallet-kit";
import { Colors } from "@/constants/theme";
import { useColorScheme } from "@/hooks/use-color-scheme";

export default function HomeScreen() {
  const router = useRouter();
  const colorScheme = useColorScheme();
  const colors = Colors[colorScheme ?? "light"];

  const {
    logout,
    session,
    wallets,
    createWallet,
    refreshWallets,
    clientState,
  } = useTurnkey();

  const isClientReady = clientState === ClientState.Ready;
  const [refreshing, setRefreshing] = useState(false);

  // Get the first Ethereum address from wallets
  const ethAccount = wallets
    ?.flatMap((w) => w.accounts || [])
    .find((a) => a.addressFormat === "ADDRESS_FORMAT_ETHEREUM");

  const walletAddress = ethAccount?.address || null;

  const truncateAddress = (addr: string) =>
    `${addr.slice(0, 6)}...${addr.slice(-4)}`;

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    try {
      await refreshWallets();
    } catch (e) {
      console.error("Refresh error:", e);
    }
    setRefreshing(false);
  }, [refreshWallets]);

  const handleCreateWallet = async () => {
    try {
      await createWallet({
        walletName: "WCPay Wallet",
        accounts: ["ADDRESS_FORMAT_ETHEREUM"],
      });
      await refreshWallets();
    } catch (error) {
      console.error("Create wallet error:", error);
      Alert.alert("Error", "Failed to create wallet");
    }
  };

  const handleScanToPay = () => {
    if (!walletAddress) {
      Alert.alert("No Wallet", "Please create a wallet first.");
      return;
    }
    router.push("/scanner");
  };

  const handleLogout = async () => {
    await logout();
  };

  return (
    <SafeAreaView
      style={[styles.container, { backgroundColor: colors.background }]}
    >
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {/* Header */}
        <View style={styles.header}>
          <Text style={[styles.title, { color: colors.primaryText }]}>
            WCPay Demo
          </Text>
          <TouchableOpacity onPress={handleLogout} style={styles.logoutButton}>
            <Text style={styles.logoutText}>Logout</Text>
          </TouchableOpacity>
        </View>

        {/* Wallet Card */}
        <View
          style={[
            styles.walletCard,
            {
              backgroundColor:
                colorScheme === "dark" ? "#1E1F20" : "#F7F7F8",
            },
          ]}
        >
          {walletAddress ? (
            <>
              <Text
                style={[styles.walletLabel, { color: colors.secondaryText }]}
              >
                Your Wallet
              </Text>
              <Text
                style={[styles.walletAddress, { color: colors.primaryText }]}
              >
                {truncateAddress(walletAddress)}
              </Text>
              <View style={styles.balanceRow}>
                <Text
                  style={[styles.balanceLabel, { color: colors.secondaryText }]}
                >
                  Network
                </Text>
                <Text
                  style={[styles.balanceValue, { color: colors.primaryText }]}
                >
                  Base (USDC)
                </Text>
              </View>

              {/* SDK Status */}
              <View style={styles.statusRow}>
                <Text
                  style={[styles.statusLabel, { color: colors.secondaryText }]}
                >
                  Status
                </Text>
                <View
                  style={[
                    styles.statusPill,
                    isClientReady ? styles.statusReady : styles.statusLoading,
                  ]}
                >
                  <Text style={styles.statusPillText}>
                    {isClientReady ? "Ready" : "Loading..."}
                  </Text>
                </View>
              </View>
            </>
          ) : (
            <View style={styles.noWalletContainer}>
              <Text
                style={[styles.noWalletText, { color: colors.secondaryText }]}
              >
                No wallet yet
              </Text>
              <TouchableOpacity
                style={[
                  styles.createWalletButton,
                  { backgroundColor: colors.primary },
                  !isClientReady && styles.buttonDisabled,
                ]}
                onPress={handleCreateWallet}
                disabled={!isClientReady}
              >
                <Text style={styles.createWalletButtonText}>
                  Create Wallet
                </Text>
              </TouchableOpacity>
            </View>
          )}
        </View>

        {/* Session Info */}
        {session && (
          <View
            style={[
              styles.sessionCard,
              {
                backgroundColor:
                  colorScheme === "dark" ? "#1E1F20" : "#F7F7F8",
              },
            ]}
          >
            <Text
              style={[styles.sessionTitle, { color: colors.secondaryText }]}
            >
              Session
            </Text>
            <Text style={[styles.sessionDetail, { color: colors.primaryText }]}>
              Org: {session.organizationId?.slice(0, 12)}...
            </Text>
            <Text style={[styles.sessionDetail, { color: colors.primaryText }]}>
              Expires:{" "}
              {session.expiry
                ? new Date(session.expiry * 1000).toLocaleTimeString()
                : "N/A"}
            </Text>
          </View>
        )}
      </ScrollView>

      {/* Scan to Pay FAB */}
      {walletAddress && (
        <View style={styles.fabContainer}>
          <TouchableOpacity
            style={[styles.fab, { backgroundColor: colors.primary }]}
            onPress={handleScanToPay}
            activeOpacity={0.8}
          >
            <Text style={styles.fabIcon}>📷</Text>
            <Text style={styles.fabText}>Scan to Pay</Text>
          </TouchableOpacity>
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 120,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 24,
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
  },
  logoutButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    backgroundColor: "#ef4444",
  },
  logoutText: {
    color: "#fff",
    fontWeight: "600",
    fontSize: 14,
  },
  walletCard: {
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
  },
  walletLabel: {
    fontSize: 13,
    fontWeight: "500",
    marginBottom: 4,
  },
  walletAddress: {
    fontSize: 20,
    fontWeight: "700",
    fontFamily: "monospace",
    marginBottom: 16,
  },
  balanceRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 8,
  },
  balanceLabel: {
    fontSize: 14,
  },
  balanceValue: {
    fontSize: 14,
    fontWeight: "600",
  },
  statusRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 8,
  },
  statusLabel: {
    fontSize: 14,
  },
  statusPill: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 999,
  },
  statusPillText: {
    fontSize: 12,
    fontWeight: "600",
  },
  statusReady: {
    backgroundColor: "#bbf7d0",
  },
  statusLoading: {
    backgroundColor: "#fde68a",
  },
  noWalletContainer: {
    alignItems: "center",
    paddingVertical: 20,
  },
  noWalletText: {
    fontSize: 16,
    marginBottom: 16,
  },
  createWalletButton: {
    paddingHorizontal: 24,
    paddingVertical: 14,
    borderRadius: 12,
  },
  createWalletButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
  buttonDisabled: {
    opacity: 0.5,
  },
  sessionCard: {
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
  },
  sessionTitle: {
    fontSize: 13,
    fontWeight: "500",
    marginBottom: 8,
  },
  sessionDetail: {
    fontSize: 13,
    marginBottom: 4,
  },
  fabContainer: {
    position: "absolute",
    bottom: 40,
    left: 20,
    right: 20,
  },
  fab: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 18,
    borderRadius: 16,
    gap: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 6,
  },
  fabIcon: {
    fontSize: 22,
  },
  fabText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "700",
  },
});
