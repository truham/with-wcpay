import { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  ScrollView,
} from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useTurnkey, ClientState } from "@turnkey/react-native-wallet-kit";
import { getWcPayClient, buildAccounts } from "@/constants/walletconnect";
import { signAllWcPayActions, SigningContext } from "@/lib/wc-pay-signer";
import { Colors } from "@/constants/theme";
import { useColorScheme } from "@/hooks/use-color-scheme";

type PaymentStep =
  | "loading"
  | "options"
  | "signing"
  | "confirming"
  | "success"
  | "failed"
  | "error";

export default function PaymentScreen() {
  const { paymentLink } = useLocalSearchParams<{ paymentLink: string }>();
  const router = useRouter();
  const colorScheme = useColorScheme();
  const colors = Colors[colorScheme ?? "light"];

  const {
    wallets,
    signRawPayload,
    signMessage,
    signAndSendTransaction,
    clientState,
  } = useTurnkey();

  // Get Ethereum account
  const ethAccount = wallets
    ?.flatMap((w) => w.accounts || [])
    .find((a) => a.addressFormat === "ADDRESS_FORMAT_ETHEREUM");
  const walletAddress = ethAccount?.address || "";

  // State
  const [step, setStep] = useState<PaymentStep>("loading");
  const [paymentOptions, setPaymentOptions] = useState<any>(null);
  const [selectedOption, setSelectedOption] = useState<any>(null);
  const [errorMessage, setErrorMessage] = useState("");
  const [txResult, setTxResult] = useState<any>(null);

  // Fetch payment options on mount
  useEffect(() => {
    if (paymentLink && walletAddress && clientState === ClientState.Ready) {
      fetchPaymentOptions();
    }
  }, [paymentLink, walletAddress, clientState]);

  const fetchPaymentOptions = async () => {
    try {
      setStep("loading");
      const client = getWcPayClient();
      const accounts = buildAccounts(walletAddress);

      const options = await client.getPaymentOptions({
        paymentLink: paymentLink!,
        accounts,
        includePaymentInfo: true,
      });

      setPaymentOptions(options);

      if (options.options.length === 0) {
        setStep("error");
        setErrorMessage("No payment options available for your wallet.");
        return;
      }

      // Auto-select the first option for simplicity
      setSelectedOption(options.options[0]);
      setStep("options");
    } catch (error: any) {
      console.error("Failed to fetch payment options:", error);
      setStep("error");
      setErrorMessage(error.message || "Failed to load payment options.");
    }
  };

  const handleConfirmPayment = async () => {
    if (!selectedOption || !paymentOptions) return;

    try {
      setStep("signing");

      const client = getWcPayClient();

      // Step 1: Get required signing actions
      const actions = await client.getRequiredPaymentActions({
        paymentId: paymentOptions.paymentId,
        optionId: selectedOption.id,
      });

      console.log(
        "[WCPay] Actions to sign:",
        actions.map((a: any) => a.walletRpc.method)
      );

      // Step 2: Sign all actions using Turnkey
      const signingContext: SigningContext = {
        signMessage,
        signRawPayload,
        signAndSendTransaction,
        walletAccount: ethAccount,
        walletAddress,
      };

      const signatures = await signAllWcPayActions(actions, signingContext);

      console.log("[WCPay] Signatures obtained:", signatures.length);

      // Step 3: Confirm payment
      setStep("confirming");

      const result = await client.confirmPayment({
        paymentId: paymentOptions.paymentId,
        optionId: selectedOption.id,
        signatures,
      });

      console.log("[WCPay] Payment result:", result);
      setTxResult(result);

      if (result.status === "succeeded") {
        setStep("success");
      } else if (result.status === "processing") {
        // Poll for final status
        setStep("success"); // Optimistic for demo
      } else {
        setStep("failed");
      }
    } catch (error: any) {
      console.error("Payment failed:", error);
      setStep("failed");
      setErrorMessage(error.message || "Payment failed.");
    }
  };

  const handleDone = () => {
    router.dismissAll();
  };

  const handleRetry = () => {
    setStep("loading");
    setErrorMessage("");
    fetchPaymentOptions();
  };

  // ─── Render helpers ──────────────────────────────────────────────────────

  const renderLoading = () => (
    <View style={styles.centered}>
      <ActivityIndicator size="large" color={colors.primary} />
      <Text style={[styles.loadingText, { color: colors.secondaryText }]}>
        Loading payment details...
      </Text>
    </View>
  );

  const renderOptions = () => {
    const info = paymentOptions?.info;
    const amount = selectedOption?.amount?.display;

    return (
      <ScrollView contentContainerStyle={styles.optionsContainer}>
        {/* Merchant info */}
        <View style={styles.merchantCard}>
          <Text style={[styles.merchantLabel, { color: colors.secondaryText }]}>
            Paying
          </Text>
          <Text style={[styles.merchantName, { color: colors.primaryText }]}>
            {info?.merchant?.name || "Merchant"}
          </Text>
        </View>

        {/* Amount */}
        <View style={styles.amountContainer}>
          <Text style={[styles.amountValue, { color: colors.primaryText }]}>
            {formatAmount(info?.amount?.value, info?.amount?.display?.decimals)}
          </Text>
          <Text style={[styles.amountSymbol, { color: colors.secondaryText }]}>
            {info?.amount?.display?.assetSymbol || "USDC"}
          </Text>
        </View>

        {/* Selected payment option details */}
        <View
          style={[
            styles.optionCard,
            {
              backgroundColor:
                colorScheme === "dark" ? "#1E1F20" : "#F7F7F8",
            },
          ]}
        >
          <Text style={[styles.optionLabel, { color: colors.secondaryText }]}>
            Payment Method
          </Text>
          <Text style={[styles.optionDetail, { color: colors.primaryText }]}>
            {amount?.assetSymbol || "USDC"} on{" "}
            {amount?.networkName || "Base"}
          </Text>
          <Text style={[styles.optionEta, { color: colors.secondaryText }]}>
            Est. {selectedOption?.etaS || "~10"}s
          </Text>
        </View>

        {/* From wallet */}
        <View
          style={[
            styles.optionCard,
            {
              backgroundColor:
                colorScheme === "dark" ? "#1E1F20" : "#F7F7F8",
            },
          ]}
        >
          <Text style={[styles.optionLabel, { color: colors.secondaryText }]}>
            From
          </Text>
          <Text style={[styles.walletAddr, { color: colors.primaryText }]}>
            {walletAddress.slice(0, 8)}...{walletAddress.slice(-6)}
          </Text>
        </View>

        {/* Data collection notice */}
        {selectedOption?.collectData && (
          <View style={styles.collectDataNotice}>
            <Text style={styles.collectDataText}>
              ℹ️ This payment requires additional info (handled via WebView).
            </Text>
          </View>
        )}

        {/* Expiration warning */}
        {info?.expiresAt && (
          <Text style={[styles.expiryText, { color: colors.secondaryText }]}>
            Expires:{" "}
            {new Date(info.expiresAt * 1000).toLocaleTimeString()}
          </Text>
        )}

        {/* Confirm button */}
        <TouchableOpacity
          style={[styles.confirmButton, { backgroundColor: colors.primary }]}
          onPress={handleConfirmPayment}
          activeOpacity={0.8}
        >
          <Text style={styles.confirmButtonText}>
            Confirm & Pay with Face ID
          </Text>
        </TouchableOpacity>

        {/* Cancel */}
        <TouchableOpacity
          style={styles.cancelButton}
          onPress={() => router.back()}
        >
          <Text style={[styles.cancelText, { color: colors.secondaryText }]}>
            Cancel
          </Text>
        </TouchableOpacity>
      </ScrollView>
    );
  };

  const renderSigning = () => (
    <View style={styles.centered}>
      <ActivityIndicator size="large" color={colors.primary} />
      <Text style={[styles.loadingText, { color: colors.primaryText }]}>
        Signing with Turnkey...
      </Text>
      <Text style={[styles.subText, { color: colors.secondaryText }]}>
        Authenticate with Face ID to approve
      </Text>
    </View>
  );

  const renderConfirming = () => (
    <View style={styles.centered}>
      <ActivityIndicator size="large" color={colors.primary} />
      <Text style={[styles.loadingText, { color: colors.primaryText }]}>
        Confirming payment...
      </Text>
      <Text style={[styles.subText, { color: colors.secondaryText }]}>
        Submitting to WalletConnect Pay
      </Text>
    </View>
  );

  const renderSuccess = () => (
    <View style={styles.centered}>
      <Text style={styles.successEmoji}>✅</Text>
      <Text style={[styles.resultTitle, { color: colors.primaryText }]}>
        Payment Successful!
      </Text>
      <Text style={[styles.resultSub, { color: colors.secondaryText }]}>
        {paymentOptions?.info?.merchant?.name || "Merchant"} has been paid.
      </Text>
      {txResult?.status && (
        <Text style={[styles.resultDetail, { color: colors.secondaryText }]}>
          Status: {txResult.status}
        </Text>
      )}
      <TouchableOpacity
        style={[styles.doneButton, { backgroundColor: colors.primary }]}
        onPress={handleDone}
      >
        <Text style={styles.doneButtonText}>Done</Text>
      </TouchableOpacity>
    </View>
  );

  const renderFailed = () => (
    <View style={styles.centered}>
      <Text style={styles.failEmoji}>❌</Text>
      <Text style={[styles.resultTitle, { color: colors.primaryText }]}>
        Payment Failed
      </Text>
      <Text style={[styles.resultSub, { color: colors.secondaryText }]}>
        {errorMessage || "Something went wrong. Please try again."}
      </Text>
      <TouchableOpacity
        style={[styles.retryButton, { backgroundColor: colors.primary }]}
        onPress={handleRetry}
      >
        <Text style={styles.retryButtonText}>Try Again</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.cancelButton} onPress={handleDone}>
        <Text style={[styles.cancelText, { color: colors.secondaryText }]}>
          Go Back
        </Text>
      </TouchableOpacity>
    </View>
  );

  const renderError = () => (
    <View style={styles.centered}>
      <Text style={styles.failEmoji}>⚠️</Text>
      <Text style={[styles.resultTitle, { color: colors.primaryText }]}>
        Error
      </Text>
      <Text style={[styles.resultSub, { color: colors.secondaryText }]}>
        {errorMessage}
      </Text>
      <TouchableOpacity style={styles.cancelButton} onPress={handleDone}>
        <Text style={[styles.cancelText, { color: colors.secondaryText }]}>
          Go Back
        </Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {step === "loading" && renderLoading()}
      {step === "options" && renderOptions()}
      {step === "signing" && renderSigning()}
      {step === "confirming" && renderConfirming()}
      {step === "success" && renderSuccess()}
      {step === "failed" && renderFailed()}
      {step === "error" && renderError()}
    </View>
  );
}

// ─── Helpers ───────────────────────────────────────────────────────────────

function formatAmount(value?: string, decimals?: number): string {
  if (!value) return "0.00";
  const dec = decimals || 6;
  const num = parseInt(value, 10);
  return (num / Math.pow(10, dec)).toFixed(2);
}

// ─── Styles ────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  centered: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 32,
  },
  loadingText: {
    fontSize: 17,
    fontWeight: "600",
    marginTop: 16,
  },
  subText: {
    fontSize: 14,
    marginTop: 8,
  },
  optionsContainer: {
    padding: 24,
    paddingBottom: 40,
  },
  merchantCard: {
    alignItems: "center",
    marginBottom: 8,
  },
  merchantLabel: {
    fontSize: 14,
    marginBottom: 4,
  },
  merchantName: {
    fontSize: 22,
    fontWeight: "bold",
  },
  amountContainer: {
    alignItems: "center",
    marginVertical: 24,
  },
  amountValue: {
    fontSize: 48,
    fontWeight: "800",
  },
  amountSymbol: {
    fontSize: 18,
    fontWeight: "500",
    marginTop: 4,
  },
  optionCard: {
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  optionLabel: {
    fontSize: 12,
    fontWeight: "500",
    marginBottom: 4,
  },
  optionDetail: {
    fontSize: 16,
    fontWeight: "600",
  },
  optionEta: {
    fontSize: 13,
    marginTop: 4,
  },
  walletAddr: {
    fontSize: 14,
    fontFamily: "monospace",
    fontWeight: "500",
  },
  collectDataNotice: {
    backgroundColor: "#fef3c7",
    padding: 12,
    borderRadius: 10,
    marginBottom: 12,
  },
  collectDataText: {
    fontSize: 13,
    color: "#92400e",
  },
  expiryText: {
    fontSize: 13,
    textAlign: "center",
    marginBottom: 20,
  },
  confirmButton: {
    paddingVertical: 18,
    borderRadius: 14,
    alignItems: "center",
    marginBottom: 12,
  },
  confirmButtonText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "700",
  },
  cancelButton: {
    paddingVertical: 12,
    alignItems: "center",
  },
  cancelText: {
    fontSize: 16,
  },
  successEmoji: {
    fontSize: 64,
    marginBottom: 16,
  },
  failEmoji: {
    fontSize: 64,
    marginBottom: 16,
  },
  resultTitle: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 8,
  },
  resultSub: {
    fontSize: 15,
    textAlign: "center",
    marginBottom: 8,
  },
  resultDetail: {
    fontSize: 13,
    marginBottom: 24,
  },
  doneButton: {
    paddingHorizontal: 48,
    paddingVertical: 16,
    borderRadius: 14,
    marginTop: 24,
  },
  doneButtonText: {
    color: "#fff",
    fontSize: 17,
    fontWeight: "700",
  },
  retryButton: {
    paddingHorizontal: 48,
    paddingVertical: 16,
    borderRadius: 14,
    marginTop: 16,
    marginBottom: 8,
  },
  retryButtonText: {
    color: "#fff",
    fontSize: 17,
    fontWeight: "700",
  },
});
